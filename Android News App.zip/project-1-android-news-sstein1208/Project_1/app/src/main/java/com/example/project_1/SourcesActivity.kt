package com.example.project_1

import android.util.Log
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity


class SourcesActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sources)

        // Retrieves the data associated with the "LOCATION" key from the Intent used to launch
        // this Activity (the one we created in the MainActivity)
        val category: String = intent.getStringExtra("Category")!!
        Log.d("MainActivity", category)
        // You can supply additional data parameters if that string has any placeholders that need filling.
        supportActionBar?.title = "Search for $category"

        //get the categories from the string array in strings.xml file
        val categories = resources.getStringArray(R.array.categories)

        val spinner: Spinner = findViewById(R.id.spinner)
        if (spinner != null) {
            val adapter = ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item, categories
            )
            spinner.adapter = adapter
        }

        //Get reference to the recycler view
        recyclerView = findViewById(R.id.RecyclerView)
        //create adapter
        val fakeSources: List<Source> = getFakeNews()
        val adapter: SourceAdapter = SourceAdapter(fakeSources)
        //assign adapter to recycler view
        recyclerView.adapter = adapter
/       //The LinearLayoutManager is used to set scroll direction (default is horizontal)
        recyclerView.layoutManager = LinearLayoutManager(this)

    }

    fun getFakeNews(): List<Source> {
        return listOf(
            Source(
                newsSource = "New York Times",
                newsText = "To celebrate the release of our new album, Unlimited Love, releasing April 1st, you have exclusive access to a limited edition vinyl copy of the album, only available to the Red Hot Chili Peppers top fans on Spotify."
            ),
            Source(
                newsSource = "New York Post",
                newsText = "To celebrate the release of our new album, Unlimited Love, releasing April 1st, you have exclusive access to a limited edition vinyl copy of the album, only available to the Red Hot Chili Peppers top fans on Spotify."
            ),
            Source(
                newsSource = "LA Times",
                newsText = "To celebrate the release of our new album, Unlimited Love, releasing April 1st, you have exclusive access to a limited edition vinyl copy of the album, only available to the Red Hot Chili Peppers top fans on Spotify."
            ),
            Source(
                newsSource = "Chicago Tribune",
                newsText = "To celebrate the release of our new album, Unlimited Love, releasing April 1st, you have exclusive access to a limited edition vinyl copy of the album, only available to the Red Hot Chili Peppers top fans on Spotify."
            ),
            Source(
                newsSource = "People Magazine",
                newsText = "To celebrate the release of our new album, Unlimited Love, releasing April 1st, you have exclusive access to a limited edition vinyl copy of the album, only available to the Red Hot Chili Peppers top fans on Spotify."
            ),
            Source(
                newsSource = "US Weekly",
                newsText = "To celebrate the release of our new album, Unlimited Love, releasing April 1st, you have exclusive access to a limited edition vinyl copy of the album, only available to the Red Hot Chili Peppers top fans on Spotify."
            ),
            Source(
                newsSource = "Glamour",
                newsText = "To celebrate the release of our new album, Unlimited Love, releasing April 1st, you have exclusive access to a limited edition vinyl copy of the album, only available to the Red Hot Chili Peppers top fans on Spotify."
            ),
            Source(
                newsSource = "GQ",
                newsText = "To celebrate the release of our new album, Unlimited Love, releasing April 1st, you have exclusive access to a limited edition vinyl copy of the album, only available to the Red Hot Chili Peppers top fans on Spotify."
            ),
            Source(
                newsSource = "Thrasher Magazine",
                newsText = "To celebrate the release of our new album, Unlimited Love, releasing April 1st, you have exclusive access to a limited edition vinyl copy of the album, only available to the Red Hot Chili Peppers top fans on Spotify."
            )

        )
    }



}