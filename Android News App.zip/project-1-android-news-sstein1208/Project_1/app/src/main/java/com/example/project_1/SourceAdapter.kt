package com.example.project_1

import androidx.recyclerview.widget.RecyclerView

class SourceAdapter(val sources: List<Source>): RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    //Takes source data and instructs UI on how each row should be displayed
    override fun getItemCount(): Int {
        // Return number of (total) rows to render
        return sources.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // Need to render a new row -- inflate (load) the XML file and return a ViewHolder
        val layoutInflater: LayoutInflater = LayoutInflater.from(parent.context)
        val view: View = layoutInflater.inflate(R.layout.row_source, parent, false)
        return ViewHolder(view)

    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        // Load data into a new row
        val currentSource = sources[position]

        holder.newsSource.text = currentSource.username
        holder.newsText.text = currentSource.handle

    }
}

    // Holds references to the Views in an already-inflated row
    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val newsSource: TextView = itemView.findViewByID(R.id.newsSource)
        val newsText: TextView = itemView.findViewByID(R.id.newsText)

    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        TODO("Not yet implemented")
    }

}