package com.example.project_1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText



class MainActivity : AppCompatActivity() {

    private lateinit var searchInput: EditText
    private lateinit var searchButton: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //Title of home page is Android News
        supportActionBar?.title = "Android News"

        //what the user typed into the searchbar
        searchInput = findViewById(R.id.search_input)
        searchButton = findViewById(R.id.search_button)
        //Convert to string


        searchButton.setOnClickListener{
            var searchInput: String = searchInput.text.toString()
            Log.d("Category",searchInput)
            val intent: Intent = Intent(this, SourcesActivity::class.java)
            intent.putExtra("Category", searchInput)

            // "Executes" our Intent to start a new Activity
            startActivity(intent)

        }
    }


}