package com.example.project_1

class Source {
    val newsSource: String,
    val newsText: String
}